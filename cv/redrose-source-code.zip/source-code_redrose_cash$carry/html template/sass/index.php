<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewpoint" content="width=device-width, initial-scale=1.0">
	<title>RED ROSE CASH & CARRY</title>
	
	<!-- bootstrap CDN-->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

	
	
	 <!-- owl-carousel cdn-->
	 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha256-UhQQ4fxEeABh4JrcmAJ1+16id/1dnlOEVCFOxDef9Lw=" crossorigin="anonymous" />
	 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" integrity="sha256-kksNxjDRxd/5+jGurZUJd1sdR2v+ClrCl3svESBaJqw=" crossorigin="anonymous" />
 
	 
	
	<!--font awesome icons-->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- linking my css file-->
	<link rel="stylesheet" href="style.css">


	


</head>
<body>
	<!--header  of the  website-->
	<header id="header">
		<div class="strip d-flex justify-content-between px-4 py-1 bg-light">
			<p></p>
			<div class="font-rale font-size-14">
				<a href="#" class="px-3 border-right border-left text-dark">Login</a>
				<a href="#" class="px-3 border-right border-left text-dark">sign in</a>

			</div>


		</div>
		<!--navigation bar bootstrap frames -->
		<nav class="navbar navbar-expand-lg navbar-dark color-second-bg">
			<div class="container-fluid">
			  <a class="navbar-brand" href="#">RedRose Cash&Carry</a>
			  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			  </button>
			  <div class="collapse navbar-collapse" id="navbarNav">
				<ul class="navbar-nav m-auto font-rubik">
				  <li class="nav-item">
					<a class="nav-link active" href="#">Home</a>
				  </li>
				  <li class="nav-item">
					<a class="nav-link" href="#">category<i class="fas fa-chevron-down"></i></a>
				  </li>
				  <li class="nav-item">
					<a class="nav-link" href="#">products<i class="fas fa-chevron-down"></i></a>
				  </li>
				  <li class="nav-item">
					<a class="nav-link" href="#">About Us</a>
				  </li>
				  
				</ul>
				<form action="@#" class="font-size-14 font-rale">

					<a href="#" class="py-3 rounded-pill color-primary-bg">
						<span class="font-size-16 px-2 text-white"><i class="fas fa-shopping-cart"></i></span>
						<span class="px-3 py-2 rounded-pill text-dark bg-light">0</span>

					</a>
				</form>


			      
			  </div>
			</div>
		  </nav>
		  <!--closing of of the navigation bar -->

	</header>
	<!-- the main site body -->
	<main id="main-site">
		<!--using the owl-carousel  cdn-->
		<section id="banner-area">
			<div class="owl-carousel owl-theme">
				<div class="item">
					<img src="../../webpics/food.png" alt="food">
				</div>
				<div class="item">
					<img src="../../webpics/cc.png" alt="cc">
				</div>
				<div class="item">
					<img src="../../webpics/www.png" alt="wwww">
				</div>
				
				<div class="item">
					<img src="../../webpics/mm.png" alt="mm">
				</div>
				<div class="item">
					<img src="../../webpics/ff.png" alt="ff">
				</div>
			</div>
		</section>

		<!--trending /top sell-->
		<section id ="top-sale">
			<div class="container py-5">
				<h3 class="font-rubik font-size-20">Trending</h3>
				<hr>
				<!--owl carousel-->
				<div class="owl-carousel owl-theme">
					<div class="item py-2" style="height: 200py; width: 205px;">
						<div class="product font-rale">
							<a href="#"><img src="../../webpics/canmeat.png" alt="canmeat" class="img-fluid"></a>
							<div class="text-center">
								<h6>Pronas Corned Beef</h6>
								
							</div>
							<div class="price p-2">
								<span>R59.99</span>
							</div>
							<button type="submit" class="btn btn-warning font-size-12">Add to Cart</button>
						</div>

					</div>
					<div class="item py-2" style=" width: 225px;">
						<div class="product font-rale">
							<a href="#"><img src="../../webpics/energydrink.png" alt="energydrink" class="img-fluid"></a>
							<div class="text-center">
								<h6>Prime Energy Drink</h6>
								
							</div>
							<div class="price p-2">
								<span>R39.99</span>
							</div>
							<button type="submit" class="btn btn-warning font-size-12">Add to Cart</button>
						</div>

					</div>
					<div class="item py-2">
						<div class="product font-rale" style=" width: 225px;">
							<a href="#"><img src="../../webpics/facewash.png" alt="facewash" class="img-fluid"></a>
							<div class="text-center">
								<h6>Rooibos Face Wash</h6>
								
							</div>
							<div class="price p-2">
								<span>R99.99</span>
							</div>
							<button type="submit" class="btn btn-warning font-size-12">Add to Cart</button>
						</div>

					</div>
				
					<div class="item py-2">
						<div class="product font-rale">
							<a href="#"><img src="../../webpics/oil.png" alt="oil" class="img-fluid"></a>
							<div class="text-center">
								<h6>Crown Cooking oil</h6>
								
							</div>
							<div class="price p-2">
								<span>R119.99</span>
							</div>
							<button type="submit" class="btn btn-warning font-size-12">Add to Cart</button>
						</div>

					</div>
				</div>
			

				<!--owl carousel-->

			</div>


		</section>
		<!-- trending/top sell end-->

		<!--special price -->
		<section id="special-price">
			<div class="container">
				<h4 class="font-rubik font-size-20">Top Price for your need</h4> 
				<div id="filters" class="button-group text-right font-oswalt font-size-16">
					<button class="btn is-checked " data-filter="*">Products</button>
					<button class="btn" data-filter=".fruit">Fruits</button>
					<button class="btn" data-filter=".refreshment">Refreshments</button>
					<button class="btn" data-filter=".electronics">Electronics</button>
                    
				</div>

				<div class="grid">
					<div class="grid-item fruit border">
						<div class="item py-2" style="width: 200px;">
							<div class="product font-rale">
								<a href="#"><img src="../../webpics/avocado.png" alt="avocado" class="img-fluid"></a>
								<div class="text-center">
									<h6>Avocado</h6>
									
								</div>
								<div class="price p-2">
									<span>R7.99</span>
								</div>
								<button type="submit" class="btn btn-warning font-size-12">Add to Cart</button>
							</div> 
						</div> 
					</div>
					<div class="grid-item refreshment border">
						<div class="item py-2" style="width: 200px;">
							<div class="product font-rale">
								<a href="#"><img src="../../webpics/cooldrink.png" alt="cooldrink" class="img-fluid"></a>
								<div class="text-center">
									<h6>Coca Cola six pack</h6>
									
								</div>
								<div class="price p-2">
									<span>86.00 for 6</span>
								</div>
								<button type="submit" class="btn btn-warning font-size-12">Add to Cart</button>
							</div> 
						</div> 
					</div> 
					<div class="grid-item electronics border">
						<div class="item py-2" style="width: 200px;">
							<div class="product font-rale">
								<a href="#"><img src="../../webpics/torch.png" alt="torch" class="img-fluid"></a>
								<div class="text-center">
									<h6>Torche camp</h6>
									
								</div>
								<div class="price p-2">
									<span>R100.00</span>
									
								</div>
								<button type="submit" class="btn btn-warning font-size-12">Add to Cart</button>
							</div> 
						</div> 
					</div>
					<div class="grid-item electronics border">
						<div class="item py-2" style="width: 200px;">
							<div class="product font-rale">
								<a href="#"><img src="../../webpics/microwave.png" alt="microwave" class="img-fluid"></a>
								<div class="text-center">
									<h6>AEA Microwave</h6>
									
								</div>
								<div class="price p-2">
									<span>R1700.00</span>
									
								</div>
								<button type="submit" class="btn btn-warning font-size-12">Add to Cart</button>
							</div> 
						</div> 
					</div>
					<div class="grid-item electronics border">
						<div class="item py-2" style="width: 200px;">
							<div class="product font-rale">
								<a href="#"><img src="../../webpics/iron.png" alt="iron" class="img-fluid"></a>
								<div class="text-center">
									<h6>Iron Phillips</h6>
									
								</div>
								<div class="price p-2">
									<span>R800.00</span>
									
								</div>
								<button type="submit" class="btn btn-warning font-size-12">Add to Cart</button>
							</div> 
						</div> 
					</div>
					<div class="grid-item electronics border">
						<div class="item py-2" style="width: 200px;">
							<div class="product font-rale">
								<a href="#"><img src="../../webpics/sams.png" alt="samsS" class="img-fluid"></a>
								<div class="text-center">
									<h6>Samsung Galaxy A12</h6>
									
								</div>
								<div class="price p-2">
									<span>R4000.00</span>
									
								</div>
								<button type="submit" class="btn btn-warning font-size-12">Add to Cart</button>
							</div> 
						</div> 
					</div>
					<div class="grid-item electronics border">
						<div class="item py-2" style="width: 200px;">
							<div class="product font-rale">
								<a href="#"><img src="../../webpics/tv.png" alt="tv" class="img-fluid"></a>
								<div class="text-center">
									<h6>Sinotec Mini tv</h6>
									
								</div>
								<div class="price p-2">
									<span>R2500.00</span>
									
								</div>
								<button type="submit" class="btn btn-warning font-size-12">Add to Cart</button>
							</div> 
						</div> 
					</div>
					<div class="grid-item refreshment border">
						<div class="item py-2" style="width: 200px;">
							<div class="product font-rale">
								<a href="#"><img src="../../webpics/pepsi.png" alt="pepsi" class="img-fluid"></a>
								<div class="text-center">
									<h6>Pepsi</h6>
									
								</div>
								<div class="price p-2">
									<span>R17.90</span>
									
								</div>
								<button type="submit" class="btn btn-warning font-size-12">Add to Cart</button>
							</div> 
						</div> 
					</div>
					<div class="grid-item refreshment border">
						<div class="item py-2" style="width: 200px;">
							<div class="product font-rale">
								<a href="#"><img src="../../webpics/coca.png" alt="coca" class="img-fluid"></a>
								<div class="text-center">
									<h6>Coca Cola</h6>
									
								</div>
								<div class="price p-2">
									<span>R23.99</span>
									
								</div>
								<button type="submit" class="btn btn-warning font-size-12">Add to Cart</button>
							</div> 
						</div> 
					</div>
					<div class="grid-item refreshment border">
						<div class="item py-2" style="width: 200px;">
							<div class="product font-rale">
								<a href="#"><img src="../../webpics/champ.png" alt="champ" class="img-fluid"></a>
								<div class="text-center">
									<h6>Leroux Champagne</h6>
									
								</div>
								<div class="price p-2">
									<span>R120.90</span>
									
								</div>
								<button type="submit" class="btn btn-warning font-size-12">Add to Cart</button>
							</div> 
						</div> 
					</div>
					<div class="grid-item electronics border">
						<div class="item py-2" style="width: 200px;">
							<div class="product font-rale">
								<a href="#"><img src="../../webpics/kettle.png" alt="kettle" class="img-fluid"></a>
								<div class="text-center">
									<h6>Kettle</h6>
									
								</div>
								<div class="price p-2">
									<span>R350.90</span>
									
								</div>
								<button type="submit" class="btn btn-warning font-size-12">Add to Cart</button>
							</div> 
						</div> 
					</div>
					<div class="grid-item refreshment border">
						<div class="item py-2" style="width: 200px;">
							<div class="product font-rale">
								<a href="#"><img src="../../webpics/fanta.png" alt="fanta" class="img-fluid"></a>
								<div class="text-center">
									<h6>Fanta</h6>
									
								</div>
								<div class="price p-2">
									<span>R22.90</span>
									
								</div>
								<button type="submit" class="btn btn-warning font-size-12">Add to Cart</button>
							</div> 
						</div> 
					</div>
					<div class="grid-item refreshment border">
						<div class="item py-2" style="width: 200px;">
							<div class="product font-rale">
								<a href="#"><img src="../../webpics/stoney.png" alt="stoney" class="img-fluid"></a>
								<div class="text-center">
									<h6>Banana</h6>
									
								</div>
								<div class="price p-2">
									<span>R9.90</span>
									
								</div>
								<button type="submit" class="btn btn-warning font-size-12">Add to Cart</button>
							</div> 
						</div> 
					</div>
					<div class="grid-item electronics border">
						<div class="item py-2" style="width: 200px;">
							<div class="product font-rale">
								<a href="#"><img src="../../webpics/gasstove.png" alt="gasstove" class="img-fluid"></a>
								<div class="text-center">
									<h6>Gas Stove mini</h6>
									
								</div>
								<div class="price p-2">
									<span>R450.00</span>
									
								</div>
								<button type="submit" class="btn btn-warning font-size-12">Add to Cart</button>
							</div> 
						</div> 
					</div>
					<div class="grid-item electronics border">
						<div class="item py-2" style="width: 200px;">
							<div class="product font-rale">
								<a href="#"><img src="../../webpics/led.png" alt="led" class="img-fluid"></a>
								<div class="text-center">
									<h6>LED Buld</h6>
									
								</div>
								<div class="price p-2">
									<span>R60.00</span>
									
								</div>
								<button type="submit" class="btn btn-warning font-size-12">Add to Cart</button>
							</div> 
						</div> 
					</div>
					<div class="grid-item fruit border">
						<div class="item py-2" style="width: 200px;">
							<div class="product font-rale">
								<a href="#"><img src="../../webpics/ban.png" alt="ban" class="img-fluid"></a>
								<div class="text-center">
									<h6>Banana</h6>
									
								</div>
								<div class="price p-2">
									<span>R9.90</span>
									
								</div>
								<button type="submit" class="btn btn-warning font-size-12">Add to Cart</button>
							</div> 
						</div> 
					</div>
					<div class="grid-item fruit border">
						<div class="item py-2" style="width: 200px;">
							<div class="product font-rale">
								<a href="#"><img src="../../webpics/watermelon.png" alt="watermelon" class="img-fluid"></a>
								<div class="text-center">
									<h6>watermelon</h6>
									
								</div>
								<div class="price p-2">
									<span>R40.00</span>
									
								</div>
								<button type="submit" class="btn btn-warning font-size-12">Add to Cart</button>
							</div> 
						</div> 
					</div>
					<div class="grid-item fruit border">
						<div class="item py-2" style="width: 200px;">
							<div class="product font-rale">
								<a href="#"><img src="../../webpics/onions.png" alt="onions" class="img-fluid"></a>
								<div class="text-center">
									<h6>brown Onions</h6>
									
								</div>
								<div class="price p-2">
									<span>R15.99</span>
									
								</div>
								<button type="submit" class="btn btn-warning font-size-12">Add to Cart</button>
							</div> 
						</div> 
					</div>
					
					<div class="grid-item fruit border">
						<div class="item py-2" style="width: 200px;">
							<div class="product font-rale">
								<a href="#"><img src="../../webpics/or.png" alt="or" class="img-fluid"></a>
								<div class="text-center">
									<h6>Orange</h6>
									
								</div>
								<div class="price p-2">
									<span>R10.00</span>
									
								</div>
								<button type="submit" class="btn btn-warning font-size-12">Add to Cart</button>
							</div> 
						</div> 
					</div>

				</div>
			</div>


		</section>


		<section id="banner-adds">

			<div class="container py-5 text-center">
				<img src="./webpics/advert-cr-500x150.jpg" alt="advert" class="img-fluid">
				<img src="./webpics/adv-cr-500x150.jpg" alt="adv" class="img-fluid">
			</div>
		</section>




	</main>
	<!--the footer  section of my website-->
	<footer id="footer" class="bg-dark text-white py-5 ">
		<div class="contianer">
			<div class="row">
				<div class="col-lg-3 col-12">

				    <h4 class="font-rubik font-size-20">Red Rose Cash&Carry</h4>
				    <p class="font-size-14 font-rale text-white-50">Red Rose Cash&Carry Your Best Local Supermarket for All Your Needs. Excellent Services and Products to Exceed Your Expectations. Embrace a Healthy Lifestyle with RED ROSE CASH&CARRY.</p>
			    </div>
				<div class="col-lg-4 font-size-20">
					<h4 class="font-rubik font-size-20">Newslatter</h4>
					<form class="form-row">
						<div class="col">
							<input type="text" class="form-control" placeholder="Email">
						</div>
						<div class="col">
							<butto type="submit" class="btn btn-primary mb-2">subscribe</button>
						</div>
					</form>
				</div>
					<div class="col-lg-2 col-12">
						<h4 class="font-rubik font-size-20">Informations</h4>
						<div class="d-flex flex-column flex-wrap">
							<a href="#" class=" font-rale font-size-14 text-white-50 pb-1">About Us</a>
							<a href="#" class=" font-rale font-size-14 text-white-50 pb-1">Delivery information</a>
							<a href="#" class=" font-rale font-size-14 text-white-50 pb-1">Privacy Policy</a>
							<a href="#" class=" font-rale font-size-14 text-white-50 pb-1">Learn More</a>
							<a href="#" class=" font-rale font-size-14 text-white-50 pb-1">Terms & Condition</a>	
						</div>
					</div>
					<div class="col-lg-2 col-12">
						<div class="d-flex flex-column flex-wrap">
						    <h4 class="font-rubik font-size-20">Account</h4>
						    <a href="#" class=" font-rale font-size-14 text-white-50 pb-1">Delivery History</a>
						    <a href="#" class=" font-rale font-size-14 text-white-50 pb-1">My account</a>
						    <a href="#" class=" font-rale font-size-14 text-white-50 pb-1">Wish List</a>
						    <a href="#" class=" font-rale font-size-14 text-white-50 pb-1">media</a>
						    <a href="#" class=" font-rale font-size-14 text-white-50 pb-1">Newslatter</a>	
                       </div>
					
					</div>
				</div>
			</div>
		</div>



	</footer>
	<div class="copyright text-center bg-dark text-white py-3">
		<p class="font-rale font-size-16">&copy;copyright 2023. design by<a href="#" class="color-second"> codewizard</a></p>
	</div>
	
	
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>




    <!--owl carousel javascript-->
	 <!-- Owl Carousel Js file -->
	 <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha256-pTxD+DSzIwmwhOqTFN+DB+nHjO4iAsbgfyFq5K5bcE0=" crossorigin="anonymous"></script>
     <!--isope cnd jquery-->
	 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.isotope/3.0.6/isotope.pkgd.min.js" integrity="sha512-Zq2BOxyhvnRFXu0+WE6ojpZLOU2jdnqbrM1hmVdGzyeCa1DgM3X5Q4A/Is9xA1IkbUeDd7755dNNI/PzSf2Pew==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
	<!--javascript-->
	<script src="./index.js"></script>

</body>
</html>
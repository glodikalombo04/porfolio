
<?php
$item_product=$product->getData();
if($_SERVER['REQUEST_METHOD']=="POST") {
    if(isset($_POST['top_sale_submit'])){
        // calling method  to add to cart
        $Cart->insert_to_cart($_POST['user_id'], $_POST['item_id']);

    }

}
?>

<!--trending /top sell-->
<section id ="top-sale">
    <div class="container py-5">
        <h3 class="font-rubik font-size-20">Trending</h3>
        <hr>
        <!--owl carousel-->
        <div class="owl-carousel owl-theme ">
            <?php foreach ($item_product as $item) {?>

            <div class="item py-2" >
                <div class="product font-rale">
                    <a href="<?php printf('%s?item_id=%s', 'product.php',$item['item_id']); ?>"><img src="<?php echo $item['item_image']??"./webpics/avocado.png";?>" alt="avocado" class="img-fluid"></a>
                    <div class="text-center">
                        <h6><?php echo $item['item_name']??"unknown"; ?></h6>

                    </div>
                    <div class="price p-2">
                        <span>R<?php echo $item['item_price']??"0"; ?></span>
                    </div>
                    <form method ="post">
                        <input type ="hidden" name="item_id" value="<?php echo $item['item_id']??'1'; ?>">
                        <input type ="hidden" name="user_id" value="<?php echo 1; ?>">
                        <button type="submit"  name="top_sale_submit" class="btn btn-warning font-size-12">Add to Cart</button>
                    </form>
                </div>

            </div>
            <?php } ?>

        </div>


        <!--owl carousel-->

    </div>


</section>
<!-- trending/top sell end-->

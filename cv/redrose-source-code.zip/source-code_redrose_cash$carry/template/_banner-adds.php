<section id="banner-adds">

    <div class="container py-5 text-center">
        <img src="./webpics/advert-cr-500x150.jpg" alt="advert" class="img-fluid">
        <img src="./webpics/adv-cr-500x150.jpg" alt="adv" class="img-fluid">
    </div>
</section>

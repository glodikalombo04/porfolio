<?php
if($_SERVER['REQUEST_METHOD']=="POST") {
    if(isset($_POST['special_price_submit'])){
        // calling method  to add to cart
        $Cart->insert_to_cart($_POST['user_id'], $_POST['item_id']);

    }

}

?>

<!--special price -->
<section id="special-price">
    <div class="container">
        <h4 class="font-rubik font-size-20">Top Price for your need</h4>
        <div id="filters" class="button-group text-right font-oswalt font-size-16">
            <button class="btn is-checked " data-filter="*">Products</button>
            <button class="btn" data-filter=".fruit">Fruits</button>
            <button class="btn" data-filter=".refreshment">Refreshments</button>
            <button class="btn" data-filter=".electronic">Electronics</button>

        </div>

        <div class="grid">
            <?php array_map(function ($item){ ?>
            <div class="grid-item border <?php echo $item['item_cat']??"unknown";?>">
                <div class="item py-2" style="width: 200px;">
                    <div class="product font-rale">
                        <a href="<?php printf('%s?item_id=%s', 'product.php',$item['item_id']); ?>"><img src="<?php echo $item['item_image']??"./webpics/avocado.png";?>" alt="avocado" class="img-fluid"></a>
                        <div class="text-center">
                            <h6><?php echo $item['item_name']??"unknown"; ?></h6>

                        </div>
                        <div class="price p-2">
                            <span>R<?php echo $item['item_price']??"0"; ?></span>
                        </div>
                        <form method ="post">
                            <input type ="hidden" name="item_id" value="<?php echo $item['item_id']??'1'; ?>">
                            <input type ="hidden" name="user_id" value="<?php echo 1; ?>">
                            <button type="submit"  name="special_price_submit" class="btn btn-warning font-size-12">Add to Cart</button>
                        </form>
                    </div>
                </div>
            </div>
            <?php },$item_product) ?>


        </div>
    </div>


</section>


<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    if (isset($_POST['delete-cart-submit'])){
        $deletedrecord = $Cart->removingcart($_POST['item_id']);
    }

}
?>
<!-- cart section-->
<section id="cart" class="py-3 mb-5">
    <div class="container-fluid w-75">
        <h6 class="font-oswalt font-size-20">Red Rose Cash&Carry Shopping Cart</h6>
        <!-- cart items-->
        <div class="row">
            <div class="col-sm-9">
                <?php

                foreach ($product->getData('cart' )as $item):
                    $cart= $product->fetchproduct($item['item_id']);
                //opening array map
                $total[] = array_map(function ($item){


                ?>
                <!--cart items-->
                <div class="row border-top py-3 mt-3">
                    <div class="col-sm-2">
                        <img src="<?php echo $item['item_image']??"./webpics/avocado"; ?>" style="height: 120px;" alt="avocado" class="img-fluid">
                    </div>
                    <div class="col-sm-8">
                        <h5 class="font-oswalt font-size-20"><?php echo $item['item_name']??"unknown";?></h5>

                        <small>by red rose cash & carry</small>
                        <!--quatntity-->
                        <div class="qty d-glex pt-2">
                            <div class="d-flex font-rale w-15">
                                <button class="qty-up border bg-light" ><i class="fas fa-angle-up"></i></button>
                                <input type="text" class="qty_input border px-2 w-100 bg-light" disabled value="1" placeholder="1">
                                <button class="qty-down border bg-light"><i class="fas fa-angle-down"></i></button>

                            </div>
                            <form method="post">
                                <input type="hidden" value="<?php echo $item['item_id']?? 0; ?>" name="item_id">
                                <button type="submit" name="delete-cart-submit" class="btn font-oswalt font-size-20 text-danger px-3 border-right ">Delete    <i class="fas fa-trash"></i></button>
                            </form>

                        </div>
                        <!--quatntity-->

                        <div class="col-sm-8 ">
                            <div class="font-size-20 text-danger font-oswalt">
                                R<span class="product_price"><?php echo $item['item_price']??0;?></span>
                            </div>
                        </div>
                    </div>

                </div>
                <!--cart items-->
                <?php
                        return $item['item_price'];
                     },$cart);
                endforeach;

                ?>

            </div>
            <!--subtotal section-->
            <div class="col-sm-3">
                <div class="sub-total border text-center mt-2">
                    <h6 class="font-size-12 font-rale text-success py-3"><i class="fas fa-check"></i> By clicking buy , you have comfirmed your order.</h6>
                    <div class="border-top py-4">
                        <h5 class="font-oswalt font-size-20">Total :(<?php echo isset($total)? count($total):0;?>) &nbsp;<span class="text-danger">R <span class="text-danger" id="deal-price"><?php echo isset($total) ? $Cart->getSum($total) : 0; ?></span></span></h5>
                        <button type="submit" class="btn btn-warning mt-3">Click to buy</button>
                    </div>
                </div>
            </div>
            <!--total section -->
        </div>
        <!-- cart items-->
    </div>
</section>
<!-- cart section-->


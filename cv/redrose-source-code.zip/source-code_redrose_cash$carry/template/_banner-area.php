
<section id="banner-area">
    <div class="owl-carousel owl-theme">
        <div class="item">
            <img src="./webpics/food.png" alt="food">
        </div>
        <div class="item">
            <img src="./webpics/cc.png" alt="cc">
        </div>
        <div class="item">
            <img src="./webpics/www.png" alt="wwww">
        </div>

        <div class="item">
            <img src="./webpics/mm.png" alt="mm">
        </div>
        <div class="item">
            <img src="./webpics/ff.png" alt="ff">
        </div>
    </div>
</section>

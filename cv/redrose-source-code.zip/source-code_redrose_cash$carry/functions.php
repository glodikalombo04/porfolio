<?php
// require mysql command
require ('database/DBredrose.php');

// need product class

require ('database/product.php');
require ('database/cart.php');

// object for DBredrose
$db= new DBredrose();

//the  object of the product
$product = new product($db);
// this function will help to get data  from any table

// cart
$Cart= new Cart($db);

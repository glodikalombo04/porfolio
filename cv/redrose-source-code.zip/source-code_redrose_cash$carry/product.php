<?php
// including the header php file
include ('header.php');

?>


<?php
/*including products description*/
include ('template/_product.php');
/* top sales section*/
include ('template/_top-sale.php');

?>



<?php
// including the footer php file
include ('footer.php');
?>

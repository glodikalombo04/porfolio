<?php
ob_start();
// including the header php file
include ('header.php');

?>

<section>
    <div>
        <img src="./webpics/bbb.png" width="400" >
        <hr>
    </div>
    <div class="col-sm-9 font-raleway font-size-16" text="centered">
        <p>
            At Red Rose Cash & Carry, we are dedicated to providing a seamless and convenient shopping experience for all your wholesale needs. As a leading e-commerce website, we specialize in offering a wide range of products at competitive prices, making us the preferred destination for businesses and individuals alike.

            Our Commitment to Quality and Value
            <hr>

            We take pride in delivering exceptional quality products that meet the highest standards. From fresh produce to household essentials, our vast selection is carefully curated to ensure that our customers receive only the best. We source our products from trusted suppliers, ensuring reliability and consistency in every purchase.

            Convenience at Your Fingertips
            <hr>

            With our user-friendly website, shopping with Red Rose Cash & Carry is a breeze. Our intuitive interface allows you to browse through our extensive product catalog, search for specific items, and make secure purchases with just a few clicks. Whether you're stocking up for your business or shopping for your household, we make it convenient and efficient.

            Dedicated Customer Support
            <hr>

            We value our customers and strive to provide exceptional service every step of the way. Our dedicated customer support team is here to assist you with any inquiries, concerns, or assistance you may need. We are committed to ensuring your satisfaction and are always ready to go the extra mile to meet your expectations.

            Join the Red Rose Cash & Carry Community
            <hr>

            We invite you to join our growing community of satisfied customers. Experience the convenience, quality, and value that Red Rose Cash & Carry offers. Start exploring our website today and discover a world of wholesale possibilities at your fingertips.

            At Red Rose Cash & Carry, we are your trusted partner for all your wholesale needs. Shop with confidence and let us exceed your expectations with our exceptional products and outstanding service.
        </p>
    </div>
</section>










<?php
// including the footer php file
include ('footer.php');
?>

<?php
 ob_start();
// including the header php file
include ('header.php');

?>
    <!--using the owl-carousel  cdn-->
<?php
/* banner area */
include ('template/_banner-area.php');


/* top sales section*/
include ('template/_top-sale.php');

/* special price section*/
include ('template/_special-price.php');

/* adds*/
include('template/_banner-adds.php')
?>





<?php
// including the footer php file
include ('footer.php');
?>


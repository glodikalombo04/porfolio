
<?php
ob_start();
// including the header php file
include ('header.php');

?>


<?php
/*cart section*/
include ('template/_cart.php');


/* top sales section*/
include ('template/_top-sale.php');

?>



<?php
// including the footer php file
include ('footer.php');
?>

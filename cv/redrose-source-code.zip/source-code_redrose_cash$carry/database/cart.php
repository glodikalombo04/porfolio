<?php

class Cart
{
    //class for  cart
  public $db = null;
  public function __construct(DBredrose $db){
      if (!isset($db->con)) return null;
      $this->db = $db;

}
// process of insertion in the  cart  table
public function insertintocart($params = null, $table ="cart"){
      if($this->db->con!=null){
          if($params != null){
              //insert into user cart
              $columns = implode(',', array_keys($params));

              $values = implode(',', array_values($params));


              // create  an sql  query
              $query_string = sprintf("INSERT INTO %s (%s) VALUES (%s)",$table,$columns,$values);

              $response=$this->db->con->query($query_string);
              return $response;
          }
      }
}

// fetch user_id  from the user i have  created  and item_id from the  product table  and insert it into the cart  table
 public function  insert_to_cart($userid, $itemid){
      if(isset($userid) && isset($itemid)){
          $params = array(
              "user_id" =>$userid,
              "item_id" =>$itemid
          );
          //creating  a result variable to   store  the result
          $respo = $this->insertintocart($params);
          if($respo){
              header("location:".$_SERVER['PHP_SELF']); // CALLING A GLOBAL PHP SEVER THE VARIABLE WILL RETURN CURRENT INDEX FILE
          }
      }
 }

  // delete cart product using  cart id
    public function  removingcart($item_id = null,$table ='cart'){
      if($item_id != null){
          $response=$this->db->con->query("DELETE FROM {$table} WHERE item_id={$item_id}");
          if($response){
              header("location:".$_SERVER['PHP_SELF']);
          }
          return $response;
      }
    }
 // calculation  of  the subtotal of  items in the cart page
     public function getSum($arr){
      if(isset($arr)){
          $sum = 0;
          foreach ($arr as $item){
              $sum +=floatval($item[0]);
          }
          return sprintf('%.2f', $sum);
      }
     }
}
<?php
// to fetcg  data  from  the  database
class product
{
    public $db = null;

    public function __construct(DBredrose $db)
    {
        if(!isset($db->con))return null;
        $this->db=$db;

    }

    // getting data from my databse
    public function getData($table='product'){
        $result=$this->db->con->query("SELECT * FROM {$table}");
        $resultarray= array();
        // this will get all the product data individually
        while($item = mysqli_fetch_array($result,MYSQLI_ASSOC)) {
            $resultarray[]=$item;
        }
        return $resultarray;
    }

    //fetching  product  using product id
    public function fetchproduct($item_id = null, $table='product'){
        if(isset($item_id)){
            $response=$this->db->con->query("SELECT * FROM {$table} WHERE item_id={$item_id}");
            $resultarray= array();
            // this will get all the product data individually
            while($item = mysqli_fetch_array($response,MYSQLI_ASSOC)) {
                $resultarray[]=$item;
            }
            return $resultarray;
        }
    }

}